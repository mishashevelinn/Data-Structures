package labs.singlyLL;

public class Main {

    public static void main(String[] args) throws Exception {
        SLinkedList<Integer> sl = new SLinkedList<Integer>();
        for(int i = 0; i < 10; i++){
            sl.insert(i);
        }
        System.out.println(sl.head.getNext().getNext().getNext().getElement());


    }
}
