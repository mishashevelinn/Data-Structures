package labs.singlyLL;

import java.awt.*;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;

public class TestSListChar {
    InputStreamReader reader; // = new InputStreamReader(System.in);
    StreamTokenizer tokens; // = new StreamTokenizer(reader);
    SLinkedList<Character> list;


    TestSListChar(SLinkedList<Character> sLinkedList) {

        list = sLinkedList;

        reader = new InputStreamReader(System.in);

        tokens = new StreamTokenizer(reader);

    }

    void run() throws Exception {

        Point p = new Point();
        Character ch;


        label:

        while (true) {

            if ((tokens.nextToken()) == StreamTokenizer.TT_WORD) {

                switch (tokens.sval) {

                    case "Q":

                        break label;

                    case "Add":
                        tokens.nextToken();
                        ch = tokens.sval.charAt(0);
                        list.insert(ch);
                        break;

                    case "Cur":

                        System.out.println(list.getCoursor());

                        break;

                    case "N":

                        System.out.println(list.gotoNext());

                        break;

                    case "B":

                        System.out.println(list.gotoBeginning());

                        break;
                    case "End":
                        list.gotoEnd();
                    case "P":
                        list.gotoPrior();
                    case "Print":
                        System.out.println(list.toString());
                    case "Mv":
                        tokens.nextToken();
                        ch = tokens.sval.charAt(0);
                        list.replace(ch);
                    case "Del":
                        list.remove();
                }

            }

        }

    }

}


}